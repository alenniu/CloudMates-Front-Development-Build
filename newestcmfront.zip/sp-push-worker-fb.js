importScripts('https://cdn.sendpulse.com/sp-push-worker-fb.js?ver=2.0');
