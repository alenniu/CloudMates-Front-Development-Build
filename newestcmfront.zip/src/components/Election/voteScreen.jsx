
import React from "react";

class VoteScreen extends React.Component {
    constructor() {
        super();
    }


    render() {
        return (
            <div >
                    <a href = "#" className = "column col-3" id = "caption"><span className= "text"><h1>Thunder</h1></span><img src = "https://upload.wikimedia.org/wikipedia/commons/1/19/Thunderstorm_in_sydney_2000x1500.png"></img></a>
                    <div className="frame col-xs-6">  
                    </div>        
            </div>  
        )  
  
    }
}

export default VoteScreen;
